 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "stdio.h"

/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    //INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    ADC_Initialize();
    UART1_Initialize();
    ADC_ChannelSelect(ADC_CHANNEL_ANA0);
    
    uint16_t analog_in = 0;     
    
    while(1)
    {
        ADC_ConversionStart();
        while(!ADC_IsConversionDone());
        analog_in = ADC_ConversionResultGet();
        printf("ADC Value1: %u\r\n", analog_in);
        
        uint8_t buttonState = IO_RC2_GetValue();
        
        if (buttonState == 0)    // button pressed
        {
            IO_RC3_SetHigh();    // LED ON manually
        }
        else
        {
            if (analog_in > 4000) 
            {
                __delay_ms(2000);
                ADC_ConversionStart();
                while(!ADC_IsConversionDone());
                analog_in = ADC_ConversionResultGet();
                printf("ADC Value2: %u\r\n", analog_in);
                if (analog_in > 4000)
                {
                    IO_RC3_SetHigh();
                    IO_RD7_SetHigh();
                }
            } else 
            {
                IO_RC3_SetLow();
                IO_RD7_SetLow();
            }
        }
        
        __delay_ms(100); 
    }   
}